# Status of Languages

| Language | name | v4.0 | v4.1 | required_without_all | val.email | required_with_all | val.boolean | reminders.reset | val.timezone |
|----------|:----:|:----:|:----:|:--------------------:|:---------:|:-----------------:|:-----------:|:---------------:|:------------:|
| Albanian | sq | -- | -- | -- | -- | -- | -- | -- | -- |
| Arabic | ar | OK | OK | OK | OK | OK | -- | -- | -- |
| Bosnian | bs | OK | OK | OK | -- | -- | -- | -- | -- |
| Brazilian | pt-BR | OK | OK | OK | OK | OK | OK | OK | OK |
| Bulgarian | bg | OK | OK | OK | OK | OK | OK | OK | OK |
| Cambodian | km | OK | OK | OK | -- | -- | -- | -- | -- |
| Catalan | ca | OK | OK | -- | -- | -- | -- | -- | -- |
| Chinese | zh-CN | OK | OK | OK | OK | OK | OK | OK | OK |
| Chinese from Taiwan | zh-TW | OK | OK | OK | OK | OK | OK | OK | OK |
| Czech | cs | OK | OK | -- | -- | -- | -- | -- | -- |
| Danish | da | OK | OK | OK | OK | OK | OK | -- | -- |
| Dutch | nl | OK | OK | OK | OK | OK | OK | OK | OK |
| Finnish | fi | -- | OK | -- | -- | -- | -- | -- | -- |
| French | fr | OK | OK | OK | OK | OK | OK | OK | OK |
| German | de | OK | OK | OK | OK | OK | OK | OK | OK |
| Greek | el | OK | OK | OK | OK | OK | OK | OK | OK |
| Hebrew | he | -- | -- | -- | -- | -- | -- | -- | -- |
| Hungarian | hu | OK | OK | OK | OK | OK | OK | -- | -- |
| Indonesian | id | OK | OK | OK | OK | OK | OK | OK | OK |
| Italian | it | OK | OK | OK | OK | OK | OK | OK | OK |
| Japanese | jp | OK | OK | OK | OK | OK | -- | -- | -- |
| Korean | ko | OK | OK | OK | OK | OK | OK | OK | OK |
| Macedonian | mk | OK | -- | -- | -- | -- | -- | -- | -- |
| Montenegrin | me | OK | OK | OK | OK | OK | -- | -- | -- |
| Norwegian Bokmål | nb | OK | OK | -- | -- | -- | -- | -- | -- |
| Polish | pl | OK | OK | -- | -- | -- | -- | -- | -- |
| Portuguese | pt | OK | OK | OK | OK | OK | OK | -- | OK |
| Romanian | ro | OK | OK | OK | -- | -- | -- | -- | -- |
| Russian | ru | OK | OK | OK | OK | OK | OK | OK | OK |
| Serbian | sr | OK | OK | -- | -- | -- | -- | -- | -- |
| Slovak | sk | OK | OK | -- | -- | -- | -- | -- | -- |
| Spanish | es | OK | OK | OK | OK | OK | OK | OK | OK |
| Swedish | sv | OK | OK | OK | OK | OK | OK | OK | OK |
| Thai | th | OK | OK | -- | -- | -- | OK |OK | OK |
| Traditional Chinese (Hong Kong) | zh-HK | OK | OK | OK | OK | OK | OK | OK | OK |
| Turkish | tr | OK | OK | OK | OK | OK | OK | OK | OK |
| Turkmen | tk | OK | OK | OK | OK | OK | OK | OK | OK |
| Vietnamese | vi | OK | OK | OK | OK | OK | OK | OK | OK |
